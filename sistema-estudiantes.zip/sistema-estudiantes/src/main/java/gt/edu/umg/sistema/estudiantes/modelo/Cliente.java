package gt.edu.umg.sistema.estudiantes.modelo;

public class Cliente {

    private int idCliente;
    private String nombre;
    private String nit;
    private String telefono;
    private String direccion;

    // Constructor vacío
    public Cliente() {
    }

    // Constructor con ID
    public Cliente(int idCliente, String nombre, String nit, String telefono, String direccion) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.nit = nit;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    // Getters y Setters
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}